Khimeta - Tookit for reporting on metagenome assembly quality

This application is part of the major project for James Euesden (jee22@aber.ac.uk)
as part of a Computer Science BSc degree.
Files in this directory:
- Execution Instructions.txt - Insructions for running the application. PLEASE READ!
- JavaDoc
- WebApplication - contains the code for the application. 
	- Within 'src->main->java->toolkit' is the Java code of the application, where
	the main file for running is 'Main'. 
	- Within 'src->main->resources->static' are the css and javascript files
	for the application View. (Plotly.js.min is open source, belongs 
	to Plotly, and is credited to   https://plot.ly/javascript/  )
	- Within 'src-main->resources->templates' are the HTML files for use
	with Thymeleaf for generating the HTML served by the application.
	- Within 'src->test->java->toolkit' are the unit and integration 
	tests of the application.
- artificialtestcontigs.fa - A test file for running
- contig.1274754.fa - A real file of one contig for running, provided by Sam Nicholls
- testsmallcontigs.fa - A real file of many contigs for running, provided by Sam Nicholls
- metagenomequalitytool-1.0-SNAPSHOT.jar - The application executable (use from command line)
- README.txt - This file :)

Application description:
The purpose of the application is to attempt to help a user
highlight potential problem areas with their metagenome assembly
data files (in FASTA, (.fa) format) using GC content percentages
with windowing and Open Reading Frame location comparissons, along
with providing a number of other uses such as inspecting ORF
Locations and displaying the percentage of unknown 'N' characters.
There are more quality measures that could be implemented, but this
is the application in its current state.

To use the application, please refer to the file 
"Execution Instructions.txt"
Once the application is running, you may paste in a number of
contiguous reads into the textarea and run the application. Note
that the size of file it can handle will be determined by how much
memory is allocated to the JVM when running the application.

If you enter bad data or an invalid parameter, you will be forced
to re-enter the data or parameter before being allowed to continue.
If you attempt to access results or a list of contigs before submitting
any data, you will be redirected to an error page. Please submit
actual data. Data is expected to be in FASTA format.

There are a number of files provided to play with the application:
'artificialtestcontigs' - contiguous reads for testing the applications
expected behaviour
'contig.1274754' - a real metagenomic contiguous read, provided by
Sam Nicholls, from the gut of a limpet. An example of a semi-large
contiguous read and how the application handles it.
'testsmallcontigs' - a number of small contiguous reads 
(largest ~5000) to show processing a number of contiguous reads
and test the thresholds for minimum lengths. These contiguous reads
come from the same assembly file as 'contig.1274754', provided by
Sam Nicholls. Just for testing some real, small data.
You may run your own real single or mixed species data as you see
fit. If you do not have your own but would like to try, copy some
data from a database from the NCBI.
If the application was developed further, the option for uploading 
files rather than pasting would be provided. The developer is 
aware of how much of a quality of life improvement this would be.
