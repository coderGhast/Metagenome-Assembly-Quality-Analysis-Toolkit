// Shared function for displaying when a function is running/loading and to inform the user.
function loadingclick(id) {
    document.getElementById(id).value = "Loading...";
}